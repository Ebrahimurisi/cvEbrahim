package com.example.cv_ebrahim

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
